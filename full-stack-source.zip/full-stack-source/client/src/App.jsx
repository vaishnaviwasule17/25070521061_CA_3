
import { useEffect, useState } from "react";
import "./App.css";

const API = import.meta.env.VITE_API_URL || "http://localhost:5000";

export default function App() {
  const [tasks, setTasks] = useState([]);
  const [title, setTitle] = useState("");
  const [subject, setSubject] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [priority, setPriority] = useState("Medium");
  const [error, setError] = useState("");

  async function loadTasks() {
    try {
      const response = await fetch(`${API}/api/tasks`);
      if (!response.ok) throw new Error("Could not load tasks");
      setTasks(await response.json());
      setError("");
    } catch {
      setError("Backend is not connected yet. Please try again later.");
    }
  }

  useEffect(() => {
    loadTasks();
  }, []);

  async function addTask(event) {
    event.preventDefault();
    if (!title.trim()) return;

    try {
      const response = await fetch(`${API}/api/tasks`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, subject, dueDate, priority })
      });

      if (!response.ok) throw new Error("Could not save task");

      const savedTask = await response.json();
      setTasks((previous) => [savedTask, ...previous]);
      setTitle("");
      setSubject("");
      setDueDate("");
      setPriority("Medium");
      setError("");
    } catch {
      setError("Task could not be saved. Check the backend connection.");
    }
  }

  async function toggleTask(task) {
    try {
      const response = await fetch(`${API}/api/tasks/${task._id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ completed: !task.completed })
      });

      if (!response.ok) throw new Error("Update failed");

      const updated = await response.json();
      setTasks((previous) =>
        previous.map((item) => item._id === updated._id ? updated : item)
      );
    } catch {
      setError("Could not update the task.");
    }
  }

  async function deleteTask(id) {
    try {
      const response = await fetch(`${API}/api/tasks/${id}`, {
        method: "DELETE"
      });
      if (!response.ok) throw new Error("Delete failed");
      setTasks((previous) => previous.filter((task) => task._id !== id));
    } catch {
      setError("Could not delete the task.");
    }
  }

  const completed = tasks.filter((task) => task.completed).length;
  const progress = tasks.length
    ? Math.round((completed / tasks.length) * 100)
    : 0;

  return (
    <main className="page">
      <header className="topbar">
        <a className="logo" href="/">🌱 TaskBloom</a>
        <span className="tagline">Small steps. Big achievements.</span>
      </header>

      <section className="welcome">
        <div>
          <p className="eyebrow">YOUR PERSONAL STUDY SPACE</p>
          <h1>Make today count ✨</h1>
          <p>Organize your assignments, track your progress, and bloom.</p>
        </div>
        <div className="progress-card">
          <span>Overall progress</span>
          <strong>{progress}%</strong>
          <div className="progress-track">
            <div style={{ width: `${progress}%` }} />
          </div>
          <small>{completed} of {tasks.length} tasks completed</small>
        </div>
      </section>

      {error && <p className="error">{error}</p>}

      <section className="layout">
        <form className="panel task-form" onSubmit={addTask}>
          <h2>＋ Add a new task</h2>
          <label>Task name</label>
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g. Complete DSA assignment"
            required
          />

          <label>Subject</label>
          <input
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            placeholder="e.g. Computer Science"
          />

          <label>Due date</label>
          <input
            type="date"
            value={dueDate}
            onChange={(e) => setDueDate(e.target.value)}
          />

          <label>Priority</label>
          <select value={priority} onChange={(e) => setPriority(e.target.value)}>
            <option>Low</option>
            <option>Medium</option>
            <option>High</option>
          </select>

          <button className="primary" type="submit">Add task +</button>
        </form>

        <section className="panel task-list">
          <div className="list-heading">
            <div>
              <h2>My tasks</h2>
              <p>Your goals, all in one place.</p>
            </div>
            <span className="count">{tasks.length} tasks</span>
          </div>

          {tasks.length === 0 ? (
            <div className="empty">
              <span>🌼</span>
              <h3>Your journey starts here!</h3>
              <p>Add your first task to get started.</p>
            </div>
          ) : (
            tasks.map((task) => (
              <article className={`task ${task.completed ? "done" : ""}`} key={task._id}>
                <input
                  type="checkbox"
                  checked={task.completed}
                  onChange={() => toggleTask(task)}
                  aria-label={`Mark ${task.title} completed`}
                />
                <div className="task-info">
                  <strong>{task.title}</strong>
                  <p>
                    {task.subject || "Personal"}
                    {task.dueDate ? ` · Due ${task.dueDate}` : ""}
                  </p>
                  <span className={`priority ${task.priority.toLowerCase()}`}>
                    {task.priority} priority
                  </span>
                </div>
                <button
                  className="delete"
                  onClick={() => deleteTask(task._id)}
                  aria-label={`Delete ${task.title}`}
                >
                  🗑
                </button>
              </article>
            ))
          )}
        </section>
      </section>

      <footer>Made with 💜 for students who want to bloom.</footer>
    </main>
  );
}
